
<?php
// No permitir acceso directo al archivo
defined('_JEXEC') or die('Restricted access');
 
// Importar librer�a de controladores de formulario de Joomla
jimport('joomla.application.component.controllerform');
 
/**
 *Controlador Equipamientoclase
 */
class CocheControllerEquipamientoclase extends JControllerForm
{
}