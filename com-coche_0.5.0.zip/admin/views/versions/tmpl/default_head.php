<?php
// No permitir el acceso directo al archivo
defined('_JEXEC') or die('Restricted Access');
?>

<tr>
        <th width="5">
                <?php echo JText::_('COM_COCHE_VERSIONS_HEADING_ID'); ?>
        </th>
        <th width="5">
                <?php echo JText::_('COM_COCHE_VERSIONS_HEADING_MARCA'); ?>
        </th>
        <th width="5">
                <?php echo JText::_('COM_COCHE_VERSIONS_HEADING_MODELO'); ?>
        </th>
        <th width="5">
                <?php echo JText::_('COM_COCHE_VERSIONS_HEADING_NOMBREVERSION'); ?>
        </th>
        <th width="5">
                <?php echo JText::_('COM_COCHE_VERSIONS_HEADING_TIPO'); ?>
        </th>
        <th width="5">
                <?php echo JText::_('COM_COCHE_VERSIONS_HEADING_COMBUSTIBLE'); ?>
        </th>
        <th width="5">
                <?php echo JText::_('COM_COCHE_VERSIONS_HEADING_ESTADO'); ?>
        </th>
        <th width="5">
                <?php echo JText::_('COM_COCHE_VERSIONS_HEADING_SELECCIONAR'); ?>
        </th>
</tr>