<?php
// No permitir el acceso directo al archivo
defined('_JEXEC') or die('Restricted Access');
?>
<tr>
        <td colspan="4"><?php echo $this->pagination->getListFooter(); ?></td>
</tr>