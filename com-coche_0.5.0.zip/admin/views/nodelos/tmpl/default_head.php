<?php
// No permitir el acceso directo al archivo
defined('_JEXEC') or die('Restricted Access');
?>

<tr>
        <th width="5">
                <?php echo JText::_('COM_COCHE_NODELOS_HEADING_ID'); ?>
        </th>
        <th width="5">
                <?php echo JText::_('COM_COCHE_NODELOS_HEADING_MARCA'); ?>
        </th>
        <th width="5">
                <?php echo JText::_('COM_COCHE_NODELOS_HEADING_NOMBREMODELO'); ?>
        </th>
        <th width="5">
                <?php echo JText::_('COM_COCHE_NODELOS_HEADING_SELECCIONAR'); ?>
        </th>
</tr>