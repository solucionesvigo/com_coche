<?php
// No permitir el acceso directo al archivo
defined('_JEXEC') or die('Restricted Access');
?>

<tr>
        <th width="5">
                <?php echo JText::_('COM_COCHE_COCHE_HEADING_ID'); ?>
        </th>
        <th width="5">
                <?php echo JText::_('COM_COCHE_COCHE_HEADING_MARCA'); ?>
        </th>
        <th width="5">
                <?php echo JText::_('COM_COCHE_COCHE_HEADING_IMAGEN'); ?>
        </th>
        <th width="5">
                <?php echo JText::_('COM_COCHE_COCHE_HEADING_SELECCIONAR'); ?>
        </th>
</tr>